const axios = require('axios');

module.exports = {
  command: 'brat',
  description: 'Crea un sticker usando texto.',
  run: async (sock, message, args) => {
    if (!args.length) {
      return message.reply('🌿. Por favor, introduzca el texto.\nEjemplo: Hola');
    }
    
    const text = args.join(' ');
    const apiUrl = `https://nirkyy-dev.hf.space/api/v1/brat?text=${encodeURIComponent(text)}&animasi=false`;
    
    try {
      await message.reply('_Espera un momento . . ._');
      
      const response = await axios.get(apiUrl, {
        responseType: 'arraybuffer'
      });
      
      const buffer = Buffer.from(response.data, 'binary');
      await message.sticker(buffer);
      
    } catch (e) {
      console.error(e);
      await message.reply('No se pudo crear el sticker. La API podría estar inactiva o el texto es demasiado largo.');
    }
  }
};