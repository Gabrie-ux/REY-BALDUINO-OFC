const fs = require('fs');
const path = require('path');

module.exports = {
  command: 'afk',
  description: 'Configuración del estado AFK.',
  run: async (sock, message, args) => {
    const userJid = message.sender;
    const reason = args.join(' ') || 'No hay razón';
    const time = Date.now();
    
    const dbPath = path.join(__dirname, '../../database/afk.json');
    
    let afkData = {};
    try {
      const fileData = fs.readFileSync(dbPath, 'utf8');
      afkData = JSON.parse(fileData);
    } catch (e) {
      console.log("Crea un nuevo archivo afk.json.");
    }
    
    afkData[userJid] = { reason, time };
    
    fs.writeFileSync(dbPath, JSON.stringify(afkData, null, 2));
    
    const afkMessage = `✅ *Ahora estás AFK*\n\n*Razón :* ${reason}`;
    await message.reply(afkMessage);
  }
};