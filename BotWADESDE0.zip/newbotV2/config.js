module.exports = {
    prefix: '.',
    ownerNumber: '51941247696',
    ownerName: "Gabriel perrolindo",
    botName: "REY BALDUINO ",
    isPublic: false,
    autoRead: true,
    autoTyping: true
};