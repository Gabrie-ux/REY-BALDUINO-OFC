const fs = require('fs');
const path = require('path');
const config = require('./config');
const { serialize } = require('./lib/serialize');

const plugins = new Map();
const pluginsDir = path.join(__dirname, 'plugins');

fs.readdirSync(pluginsDir).forEach(category => {
    const categoryDir = path.join(pluginsDir, category);
    if (fs.statSync(categoryDir).isDirectory()) {
        fs.readdirSync(categoryDir).forEach(file => {
            if (path.extname(file) === '.js') {
                try {
                    const pluginPath = path.join(categoryDir, file);
                    const plugin = require(pluginPath);
                    if ((plugin.command || plugin.customPrefix) && plugin.run) {
                        const keys = Array.isArray(plugin.customPrefix)
                            ? plugin.customPrefix
                            : [plugin.command || plugin.customPrefix];
                        for (const key of keys) {
                            plugins.set(key.toLowerCase(), plugin);
                        }
                    }
                } catch (e) {
                    console.error(` 🍃. No se pudo cargar el plugin ${file} en la categoría ${category} :`, e);
                }
            }
        });
    }
});

function formatAfkDuration(ms) {
    const seconds = Math.floor((ms / 1000) % 60);
    const minutes = Math.floor((ms / (1000 * 60)) % 60);
    const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
    const days = Math.floor(ms / (1000 * 60 * 60 * 24));
    let duration = [];
    if (days > 0) duration.push(`${days} día(s)`);
    if (hours > 0) duration.push(`${hours} hora(s)`);
    if (minutes > 0) duration.push(`${minutes} minuto(s)`);
    if (seconds > 0) duration.push(`${seconds} segundo(s)`);
    return duration.join(', ') || 'no sé w';
}

module.exports = async (sock, m) => {
    if (!m) return;
    const message = await serialize(sock, m);
    const dbDir = path.join(__dirname, 'database');
    if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir);
    const afkPath = path.join(dbDir, 'afk.json');
    if (!fs.existsSync(afkPath)) fs.writeFileSync(afkPath, '{}');
    let afkData = JSON.parse(fs.readFileSync(afkPath));
    const mentionedJids = message.msg?.contextInfo?.mentionedJid || [];

    if (afkData[message.sender]) {
        const afkInfo = afkData[message.sender];
        const duration = formatAfkDuration(Date.now() - afkInfo.time);
        await message.reply(`🌴 *¡Bienvenido de nuevo!*\n\nHas estado AFK por *${duration}*.`);
        delete afkData[message.sender];
        fs.writeFileSync(afkPath, JSON.stringify(afkData, null, 2));
    }

    for (const jid of mentionedJids) {
        if (afkData[jid]) {
            const afkInfo = afkData[jid];
            const duration = formatAfkDuration(Date.now() - afkInfo.time);
            const response = `🌷 ¡No lo molestes!\n\n*Usuario:* @${jid.split('@')[0]}\n*Estado:* AFK desde hace *${duration}*\n*Motivo:* ${afkInfo.reason}`;
            await sock.sendMessage(message.from, { text: response, mentions: [jid] }, { quoted: message });
        }
    }

    if (config.autoRead) {
        await sock.readMessages([message.key]);
    }

    const ownerJid = `${config.ownerNumber}@s.whatsapp.net`;
    const botJid = sock.user.id.split(':')[0] + `@s.whatsapp.net`;
    const isOwner = message.sender === ownerJid;
    const isBot = message.sender === botJid;

    if (!config.isPublic && !isOwner && !isBot) {
        return;
    }

    if (!message.body) return;

    let command = '';
    let args = [];
    let plugin = null;

    if (message.body.startsWith(config.prefix)) {
        args = message.body.slice(config.prefix.length).trim().split(/ +/);
        command = args.shift().toLowerCase();
        plugin = plugins.get(command);
    } else {
        const text = message.body.trim().toLowerCase();
        for (const [key, p] of plugins.entries()) {
            if (p.customPrefix && text === key) {
                plugin = p;
                args = text.slice(key.length).trim().split(/ +/);
                command = key;
                break;
            }
        }
    }

    if (!plugin) return;

    if (config.autoTyping) {
        await sock.sendPresenceUpdate('composing', message.from);
    }

    try {
        await plugin.run(sock, message, args)
    } catch (e) {
        console.error(` 🏝️. Error al ejecutar el plugin : ${command}:`, e);
        message.reply(` 🌹. Error : ${e.message}`);
    }
};